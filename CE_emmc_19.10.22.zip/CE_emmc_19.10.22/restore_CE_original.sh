#!/bin/sh

# SPDX-License-Identifier: GPL-2.0-or-later
# (C) emerson@linuxforum.hu


    if [ -f /media/COREELEC/kernel.img.bak ] ; then    
     cp /media/COREELEC/kernel.img /media/COREELEC/ext4-kernel.img
     cp /media/COREELEC/kernel.img.bak /media/COREELEC/kernel.img
     echo ""
     echo "Original system restored!"
     read -p "Reboot now [y/N]? " choice
     case "$choice" in
      [yY]*)
      reboot
      ;;
     esac
    else
     echo "No original kernel image found, exiting!"
    fi


