#!/bin/sh

# SPDX-License-Identifier: GPL-2.0-or-later
# (C) emerson@linuxforum.hu

KERNEL="/flash/ext4-kernel.img"
OFFSET="/flash/offset"

    if [ -f $KERNEL -a -f $OFFSET ] ; then    
     mount -o rw,remount /flash
     cp /flash/kernel.img /flash/kernel.img.bak
     cp $KERNEL /flash/kernel.img
     echo ""     
     echo "eMMC system restored!"
     read -p "Reboot now [y/N]? " choice
     case "$choice" in
      [yY]*)
        reboot
        ;;
     esac
    else
     echo "No system files found, exiting!"
    fi



