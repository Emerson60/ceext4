#!/bin/sh

# SPDX-License-Identifier: GPL-2.0-or-later
# (C) emerson@linuxforum.hu


DATAOFFSET=$(dmesg | grep mmcblk | grep ' data' | awk '{ print $6}'| sed "s/.$//g" | head -n 1)
DATASIZE=$(dmesg | grep mmcblk | grep ' data' | awk '{ print $8}' | head -n 1)
OFFSET=$(printf "%d\n" $DATAOFFSET)
SIZE=$(printf "%d\n" $DATASIZE)
HALFSIZE=$(($SIZE /2))
SECTOR=$(($HALFSIZE /512))
CEOFFSET=$(($HALFSIZE + 4096 + $OFFSET))
EMMCDEV="/dev/mmcblk0"
KERNEL="/storage/backup/ext4-kernel.img"
SYSTEM="/flash/SYSTEM"
LOOPDEV="/dev/loop1"

mkdir /tmp/mnt
mkdir /tmp/sys

 losetup -f -o "$OFFSET" "$EMMCDEV"
 mount "$LOOPDEV" /tmp/mnt
 FREESPACE=$(df "$LOOPDEV" | awk 'NR==2 { print $4 }')
 FREESPACE=$((FREESPACE * 1024))
 umount "$LOOPDEV"
 losetup -D
 if [ $FREESPACE -lt $HALFSIZE ]; then
   echo "Not enough space on Android data partition. Exiting!"
   exit 1
 fi

install_to_ext4() {
  if [ -f $KERNEL -a -f $SYSTEM ] ; then
    echo ""
    echo "Resizing Android data..."
    losetup -f -o "$OFFSET" "$EMMCDEV"
    e2fsck -f -y "$LOOPDEV" > /dev/null
    resize2fs "$LOOPDEV" "$SECTOR"s > /dev/null
    sync
    losetup -D
    echo "done."

    mount -o rw,remount /flash

    echo ""
    echo -n "Create offset config file on /flash..."
    echo $CEOFFSET > /flash/offset
    echo "done."

    echo ""
    echo -n "Backing up original kernel.img..."
    mv /flash/kernel.img /flash/kernel.img.bak
    echo "done."

    echo ""
    echo "Copy ext4 kernel.img to /flash..."
    cp $KERNEL /flash/kernel.img
    echo "done."

    echo""
    echo -n "Formatting ext4 system partition..."
    losetup -f -o "$CEOFFSET" "$EMMCDEV"
    mke2fs -F -q -t ext4 -m 0 "$LOOPDEV" > /dev/null
    echo "done."

    echo ""
    echo -n "Copying ext4 rootfs..."
    sleep 2
    mount -o loop "$SYSTEM" /tmp/sys
    mount "$LOOPDEV" /tmp/mnt
    rsync -a /tmp/sys/ /tmp/mnt/ > /dev/null
    sync
    echo "done."

    echo ""
    echo -n "Copy your user data to eMMC..."
    systemctl stop kodi
    rsync -a /storage/ /tmp/mnt/storage/ > /dev/null
    sync
    echo "done."
    echo ""
    echo "All done!"
    echo ""
    read -p "Reboot to ext4 system now [y/N]? " choice
    case "$choice" in
     [yY]*)
     reboot
     ;;
    esac

  else
    echo "No system files found! Exiting..."
  fi
}

clear
echo ""
echo "This installer resizing Android data partition, and install CoreELEC ext4"
echo "systen on box."
echo ""
echo "Start?"
echo ""
read -p "Type \"yes\" if you know what you are doing or anything else to exit: " choice
case "$choice" in
 yes)
 install_to_ext4
 ;;
esac


